function [ output_args ] = stitch( input_args )
%STITCH Summary of this function goes here
%   Detailed explanation goes here


end

